import functions
import restraunant
from flask import Flask, render_template, request, session
from flask_cors import CORS
import predict
app = Flask(__name__, template_folder="./", static_folder="./assests")
CORS(app)
app.secret_key = 'SmartTourisProject'


@app.route('/', methods=['GET'])
def loginpage():
    return render_template("login.html")


@app.route('/searchHotels', methods=['GET'])
def hotelage():
    return render_template("hotels.html")


@app.route('/signup', methods=['GET'])
def signuppage():
    return render_template("signup.html")


@app.route('/adduser', methods=['POST'])
def signup():
    # print(request.json)
    email = request.json["email"]
    password = request.json["password"]

    #print(email, password)
    checker = functions.addUserInDB(email, password)

    if checker:
        return {"status": "true"}
    else:
        return {"status": "false"}


@app.route('/loginServer', methods=['POST'])
def login():
    # print(request.json)
    email = request.json["email"]
    password = request.json["password"]
    checker = functions.checkUserInDb(email, password)
    # print(checker)

    if checker:
        session["user"] = email
        return {"status": "true"}
    else:
        return {"status": "false"}


@app.route('/getHotelRecommendation', methods=['GET'])
def getHotelRecommendation():
    resp = functions.getRecommendationBasisPreviousSearSch(session['user'])
    print(resp)
    return {"data": resp}


@app.route('/getResRecommendation', methods=['GET'])
def getResRecommendation():
    resp = functions.getRecommendationBasisPreviousRes(session['user'])
    print(resp)
    return {"data": resp}


@app.route('/submitdata', methods=['POST'])
def submitdata():
    # print(request.json)
    source = request.json["source"]
    destination = request.json["dest"]
    data = request.json["data"]
    room = request.json["room"]
    #print('value of room type is ', roomtype)
    #print('value of source dest data ', source, destination, data)
    #checker = functions.checkUserInDb(email, password)
    #test = predict.requirementbased(destination, int(data), 'near to airport')
    test = predict.requirementbased(source, int(data), destination)
    print('the value of test is ', test)
    #print("source ", source)
    #print("destination ", destination)
    #print("data ", data)
    #print("session ", session.get("user"))

    #data1 = test[0]
    #data2 = test[1]

    #print('data1 ', data1)
    #print('data2', data2)
    # data1 = {"name": "Taj hotel", "price": "10000",
    #          "recommended_places": ["marine lines", "dadar chowpatty"]}
    # data2 = {"name": "Oberio hotel", "price": "8000",
    #          "recommended_places": ["India gate", "national park"]}
    #data = [data1, data2]

    if test:
        return {"status": "true", "data": test}
    else:
        return {"status": "false"}
    # return data


@app.route('/bookhotel', methods=['GET'])
def bookhotel():
    print(session)
    return render_template("bookhotel.html")


@app.route('/bookinghotel', methods=['POST'])
def bookinghotel():
    # print(request.json)
    name = request.json["name"]
    adult = request.json["adult"]
    datefrom = request.json["from"]
    dateto = request.json["to"]
    children = request.json["children"]
    price = request.json["price"]
    paid = request.json["paid"]
    add = request.json['add']
    email = session.get("user")
    if email:
        checker = functions.addBookingDataInDB(
            email, name, adult, datefrom, dateto, children, price, paid, add)
        if checker:

            # ............................

            functions.sendMail(email, name, datefrom, dateto, price)
            return {"status": "true"}
        else:
            return {"status": "false"}
    else:
        return {"status": "false"}


@app.route('/logout', methods=['GET'])
def logout():
    if session.get("user"):
        session.pop('user')
        return {"status": "true"}
    else:
        return {"status": "false"}


@app.route('/bookflight', methods=['GET'])
def bookflight():
    return render_template("bookflight.html")


@app.route('/bookingflight', methods=['POST'])
def bookingflight():
    # print(request.json)
    from_ = request.json["from"]
    to = request.json["to"]
    departure = request.json["departure"]
    return_date = request.json["return_date"]
    type = request.json["type"]
    price = request.json["price"]
    email = session.get("user")
    if email:
        checker = functions.addFlightBookingDataInDB(
            from_, to, departure, return_date, type, email, price)
        if checker:
            functions.sendMailFlight(email, from_, to)
            return {"status": "true"}
        else:
            return {"status": "false"}
    else:
        return {"status": "false"}


@app.route('/select', methods=['GET'])
def select():
    return render_template("select.html")


@app.route('/payhotel', methods=['GET'])
def payhotel():
    return render_template("payhotel.html")


@app.route('/recomrest', methods=['GET'])
def recomrest():
    return render_template('recom.html')


@app.route('/submitresdata', methods=['POST'])
def submitresdata():
    city = request.json["city"]
    locality = request.json["locality"]
    cusisine = request.json["cuisine"]
    print(city, locality)
    data = restraunant.requirementbased(city, locality, cusisine)
    data = data.to_json()
    print('data=============', data)
    print(data)
    if data:
        email = session.get("user")
        functions.addResDataInDB(email, city, locality, cusisine)
        return {"status": "true", "data": data}
    else:
        return {"status": "false"}


@app.route('/getallbooking', methods=['GET'])
def getallbooking():
    email = session.get('user')
    if email:
        data = functions.getallbooking(email)
        print(data)
        if data:
            return render_template('getallbooking.html', data=data)
        else:
            return render_template('error.html')
    else:
        return render_template('error.html')


@app.route('/paymentsuccessful', methods=['GET'])
def payment():
    return render_template('paymentsuccessful.html')


if __name__ == '__main__':
    app.run(debug=True)
