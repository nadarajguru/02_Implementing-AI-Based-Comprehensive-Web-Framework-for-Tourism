from email import message
from urllib import response
import pymongo
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import predict
import smtplib
import ssl
my_client = pymongo.MongoClient("mongodb://localhost:27017/")


def addUserInDB(email, password):
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    check = my_col.find_one({"email": email})
    if check:
        return False
    else:
        finder = my_col.insert_one(
            {"email": email, "password": password})
        print(finder)
        if finder:
            return True
        else:
            return False


def checkUserInDb(email, password):
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    finder = my_col.find_one({"email": email, "password": password})
    print(finder)
    if finder:
        return True
    else:
        return False


def sendMail(email, name, datefrom, dateto, price):
    port = 465
    smtp_server = "smtp.gmail.com"
    sender_email = "group.02.smart.tourism@gmail.com"
    password = "jnh_group_02"
    message = """
        \Subject : Booking Confirmation



        Your Bookings has been confirmed with us.

        """+"your Hotel name :" + name + """
        """+"booking from :" + datefrom + """
        """+"booking till :" + dateto + """
        """+"at price :" + price + """
    """

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context)as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, email, message)


def sendMailFlight(email, fr, to):
    port = 465
    smtp_server = "smtp.gmail.com"
    sender_email = "group.02.smart.tourism@gmail.com"
    password = "jnh_group_02"
    message = """
        \Subject : Booking Confirmation



        Your Bookings has been confirmed with us.
        
        """+"your flight from :" + fr + """
        """+"your flight to :" + to + """

    """

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context)as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, email, message)


# sendMail("harshaj167@gmail.com", "harshu", "12-02-2022", "13-02-2022", "1200")

# def sendemail(email):
#     message = Mail(
#         from_email='yashnik64@gamil.com',
#         to_emails=email,
#         subject='Sending with Twilio SendGrid is Fun',
#         html_content='<strong>and easy to do anywhere, even with Python</strong>')
#     try:
#         sg = SendGridAPIClient(
#             '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')
#         response = sg.send(message)
#         print(response.status_code)
#         print(response.body)
#         print(response.headers)
#     except Exception as e:
#         print('e', e)


# sendMail("rgupta2812@gmail.com")


def addBookingDataInDB(email, name, adult, datefrom, dateto, children, price, paid, add):
    print(name)
    print(adult)
    print(datefrom)
    print(dateto)
    print(email)
    print(children)
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    add = my_col.update_one(
        {'email': email}, {'$push': {'data': {'hotel_name': name, 'adult': adult, 'children': children, 'from': datefrom, 'to': dateto, 'price': price, 'paid': paid, 'address': add}}}, upsert=True)
    print(add)
    if add:
        print(add)
        #emailsend = sendemail(email)
        return True
    else:
        return False


def addFlightBookingDataInDB(from_, to, departure, return_date, type, email, price):
    print(from_, to, departure, return_date, type, email)
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    add = my_col.update_one(
        {'email': email}, {'$push': {'flight_data': {'from': from_, 'to': to, 'departure': departure, 'return_date': return_date, 'type': type, 'price': price}}}, upsert=True)
    print(add)
    if add:
        print(add)
        #emailsend = sendemail(email)
        return True
    else:
        return False


def addResDataInDB(email, city, location, cuisine):
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    add = my_col.update_one(
        {'email': email}, {'$push': {'res_data': {"city": city, "locality": location, "cuisine": cuisine}}}, upsert=True)
    print(add)
    if add:
        print(add)
        #emailsend = sendemail(email)
        return True
    else:
        return False


def getRecommendationBasisPreviousSearSch(username):
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    data = my_col.find_one({'email': username})
    print(data["data"])
    hotels = []
    for i in data["data"]:
        if(i["hotel_name"]):
            hotels.append(i["hotel_name"].lower())

    response = predict.getAdditionalHotels(hotels)
    return response


def getRecommendationBasisPreviousRes(username):
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    data = my_col.find_one({'email': username})
    # print(data["data"])
    hotels = []
    for i in data["res_data"]:
        if(i["city"]):
            hotels.append({" city": i["city"].lower(),
                          "cuisine": i["cuisine"].lower()})

    response = predict.getAdditionalRes(hotels)
    return response
    # print(response)


# getRecommendationBasisPreviousRes('test')


# getRecommendationBasisPreviousSearSch()


def getallbooking(email):
    print('email----------', email)
    my_db = my_client["SmartTourism"]
    my_col = my_db["User"]
    data = my_col.find_one({'email': email})

    print(data['data'])

    return data['data']
