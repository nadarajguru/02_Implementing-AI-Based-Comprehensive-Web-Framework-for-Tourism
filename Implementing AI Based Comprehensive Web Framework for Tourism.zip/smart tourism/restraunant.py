from nltk.corpus import wordnet
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.stem.snowball import SnowballStemmer
from nltk.tokenize import word_tokenize
import numpy as np
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import json

df = pd.read_csv('zomato.csv',  encoding="ISO-8859-1")

hotel_data1 = df.drop(columns=['Restaurant ID', 'Country Code', 'Locality Verbose', 'Longitude',
                               'Latitude', 'Currency', 'Has Table booking', 'Has Online delivery',
                               'Is delivering now', 'Switch to order menu', 'Price range', 'Aggregate rating',
                               'Rating color', 'Rating text',
                               'Votes', ])


hotel = hotel_data1.dropna()

print(hotel.columns)


def requirementbased(city, Locality, cusine):
    print(hotel)
    hotel['City'] = hotel['City'].str.lower()
    hotel['Locality'] = hotel['Locality'].str.lower()
    hotel['Cuisines'] = hotel['Cuisines'].str.lower()
    Locality = Locality.lower()
    Locality_tokens = word_tokenize(Locality)
    sw = stopwords.words('english')
    lemm = WordNetLemmatizer()
    f1_set = {w for w in Locality_tokens if not w in sw}
    f_set = set()
    for se in f1_set:
        f_set.add(lemm.lemmatize(se))

    reqbased = hotel[hotel['Cuisines'] == cusine.lower()]
    reqbased = hotel[hotel['City'] == city.lower()]
    reqbased = reqbased.set_index(np.arange(reqbased.shape[0]))

    l1 = []
    l2 = []
    cos = []
    # print(reqbased['roomamenities'])
    for i in range(reqbased.shape[0]):
        temp_tokens = word_tokenize(reqbased['Locality'][i])
        temp1_set = {w for w in temp_tokens if not w in sw}
        temp_set = set()
        for se in temp1_set:
            temp_set.add(lemm.lemmatize(se))
        rvector = temp_set.intersection(f_set)
        # print(rvector)
        cos.append(len(rvector))
    reqbased['similarity'] = cos
    reqbased = reqbased.sort_values(by='similarity', ascending=False)
    test = reqbased[['Restaurant Name', 'Address', 'Cuisines',
                     'Average Cost for two']].head(10)
    # return list(test.T.to_dict().values())
    return test


# print(requirementbased('mumbai', 'borivali'))
