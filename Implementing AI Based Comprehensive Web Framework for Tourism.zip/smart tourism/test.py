import json
import numpy as np


def unique(list1):
    x = np.array(list1)
    return np.unique(x)


data = open("./newZomato.json", 'r', encoding='utf-8')
data = json.load(data)

dropdownValuesCity = []
dropdowLocality = []
dropdownValueCuisine = []

for i in data:
    dropdownValuesCity.append(i["City"])
    dropdowLocality.append(i["Locality"])
    dropdownValueCuisine.append(i["Cuisines"])


unique_dropdown_city = unique(dropdownValuesCity)
unique_dropdown_locality = unique(dropdowLocality)
unique_dropdown_cuisine = unique(dropdownValueCuisine)


print(unique_dropdown_city)
print(unique_dropdown_locality)
print(unique_dropdown_cuisine)
