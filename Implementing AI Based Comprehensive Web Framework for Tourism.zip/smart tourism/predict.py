from nltk.corpus import wordnet
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.stem.snowball import SnowballStemmer
from nltk.tokenize import word_tokenize
import numpy as np
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import json

df = pd.read_csv('book.csv')

hotel = df.drop(columns=['additional_info', 'crawl_date', 'hotel_brand', 'hotel_category',
                         'hotel_description', 'image_count', 'latitude', 'locality', 'longitude', 'pageurl', 'property_id',
                         'province', 'qts', 'query_time_stamp', 'review_count_by_category',
                         'room_area', 'room_facilities',
                         'similar_hotel', 'site_review_count',
                         'site_stay_review_rating', 'sitename', 'state', 'uniq_id'])

df1 = pd.read_excel('zomato.xlsx')
res = df1.drop(columns=['Rating color', 'Votes', 'Rating text',
               'Switch to order menu', 'Has Online delivery', 'Latitude', 'Longitude', 'Price range', 'Has Table booking',
                        'Is delivering now', 'Currency', 'Country Code', 'Restaurant ID'
                        ])


# hotel = hotel_data1.dropna()


def citybased(city):
    hotel['city'] = hotel['city'].str.lower()
    citybase = hotel[hotel['city'] == city.lower()]
    citybase = citybase.sort_values(by='hotel_star_rating', ascending=False)
    if(citybase.empty == 0):
        hname = citybase[['property_name', 'hotel_star_rating',
                          'address', 'hotel_facilities', 'property_type']]
        print(hname.head())
        return hname.head()
    else:
        print('No Hotels Available')


def getAdditionalHotels(names):
    hotel['property_name'] = hotel['property_name'].str.lower()
    data = []
    for i in names:
        hotelbase = hotel[hotel['property_name'] == i.lower()]
        if(hotelbase['city'].any()):
            # print("----", hotelbase['city'].item())
            data.append(json.loads(
                citybased(hotelbase['city'].item()).to_json()))

    # print(data)
    return data


def getAdditionalRes(names):
    res['Cuisines'] = res['Cuisines'].str.lower()
    for i in names:
        hotelbase = res[res['Cuisines'] == i['cuisine'].lower()]
        data = json.loads(hotelbase.to_json())

        # if(hotelbase['City'].any()):
        # print("----", hotelbase['City'].item())
        #     data.append(json.loads(
        #         citybased(hotelbase['City'].item()).to_json()))

        # print(data)
    return data

# getAdditionalHotels(['Taj hotel', 'Taj Plaza', 'Ashiyana'])


def requirementbased(city, rating, features):
    hotel['city'] = hotel['city'].str.lower()
    hotel['hotel_facilities'] = hotel['hotel_facilities'].str.lower()
    features = features.lower()
    features_tokens = word_tokenize(features)
    sw = stopwords.words('english')
    lemm = WordNetLemmatizer()
    f1_set = {w for w in features_tokens if not w in sw}
    f_set = set()
    for se in f1_set:
        f_set.add(lemm.lemmatize(se))
    reqbased = hotel[hotel['city'] == city.lower()]
    reqbased = reqbased[reqbased['hotel_star_rating'] == rating]
    reqbased = reqbased.set_index(np.arange(reqbased.shape[0]))
    l1 = []
    l2 = []
    cos = []
    # print(reqbased['roomamenities'])
    for i in range(reqbased.shape[0]):
        temp_tokens = word_tokenize(reqbased['hotel_facilities'][i])
        temp1_set = {w for w in temp_tokens if not w in sw}
        temp_set = set()
        for se in temp1_set:
            temp_set.add(lemm.lemmatize(se))
        rvector = temp_set.intersection(f_set)
        # print(rvector)
        cos.append(len(rvector))
    reqbased['similarity'] = cos
    reqbased = reqbased.sort_values(by='similarity', ascending=False)
    test = reqbased[['property_name', 'hotel_star_rating', 'address',
                     'hotel_facilities', 'property_type', 'point_of_interest', 'rate']].head(2)
    return list(test.T.to_dict().values())


# city_hotels = citybased('mumbai')

# print(city_hotels)

# feature_wise = requirementbased('Delhi', 4, 'near to airport')

# print(feature_wise)
